<?php

include_once OBSIUS_CORE_INC_PATH . '/content/helper.php';
