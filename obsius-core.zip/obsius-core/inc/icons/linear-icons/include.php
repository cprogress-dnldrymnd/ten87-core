<?php

include_once OBSIUS_CORE_INC_PATH . '/icons/linear-icons/class-obsiuscore-linear-icons-pack.php';
