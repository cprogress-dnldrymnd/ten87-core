<?php

include_once OBSIUS_CORE_INC_PATH . '/icons/font-awesome/class-obsiuscore-font-awesome-pack.php';
