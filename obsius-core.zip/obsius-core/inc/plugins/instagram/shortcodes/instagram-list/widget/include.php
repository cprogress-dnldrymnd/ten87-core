<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-obsiuscore-instagram-list-widget.php';
