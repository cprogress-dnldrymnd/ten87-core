<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/woocommerce/class-obsiuscore-woocommerce.php';
