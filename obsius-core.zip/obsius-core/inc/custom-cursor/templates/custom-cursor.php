<span id="qodef-custom-cursor">
	<span id="qodef-cursor-dot-large-holder" class="qodef-custom-cursor">
		<span class="qodef-cursor-dot-large"></span>
	</span>
	<span id="qodef-cursor-dot-small-holder" class="qodef-custom-cursor">
		<span class="qodef-cursor-dot-small"></span>
	</span>
	<span class="qodef-cursor-text-holder">
		<span class="qodef-cursor-read-text">
			<?php echo esc_attr__( 'Read', 'obsius-core' ) ?>
		</span>
		<span class="qodef-cursor-view-text">
			<?php echo esc_attr__( 'View', 'obsius-core' ) ?>
		</span>
	</span>
</span>

