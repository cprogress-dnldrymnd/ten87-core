<?php

include_once OBSIUS_CORE_INC_PATH . '/core-dashboard/class-obsiuscore-dashboard.php';
