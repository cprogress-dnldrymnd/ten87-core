<?php

include_once OBSIUS_CORE_INC_PATH . '/opener-icon/helper.php';
