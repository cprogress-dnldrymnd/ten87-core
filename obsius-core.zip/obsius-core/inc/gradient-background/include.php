<?php

include_once OBSIUS_CORE_INC_PATH . '/gradient-background/helper.php';
include_once OBSIUS_CORE_INC_PATH . '/gradient-background/dashboard/admin/gradient-background-options.php';
include_once OBSIUS_CORE_INC_PATH . '/gradient-background/dashboard/meta-box/gradient-background-meta-box.php';